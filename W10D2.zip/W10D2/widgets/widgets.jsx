import React from 'react';
import ReactDOM from 'react-dom';

import { Root } from 'root';
// import Tabs from './front/tabs';


document.addEventListener("DOMContentLoaded", () => {
    const main = document.getElementById('main');
    ReactDOM.render(<Root />, main);
    // ReactDOM.render(<Tabs />, root);
});