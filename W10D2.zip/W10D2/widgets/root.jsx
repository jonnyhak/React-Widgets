import React from 'react';

import Clock from './frontend/clock';
import Tabs from './frontend/tabs';

//functional components are just pure functions
//props is an object used to pass data down through components
export const Root = (props) => {

    return (
        <>
            <Clock />
            <Tabs />
        </>
    )
};