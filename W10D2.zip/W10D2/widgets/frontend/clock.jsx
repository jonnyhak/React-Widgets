import React from 'react';

class Clock extends React.Component {
    
    constructor(props){
        super(props);
        this.state = { 
            date: new Date(),
        };
        this.tick = this.tick.bind(this)
    }

    tick(e) {
        // e.preventDefault();
        this.setState({ date: new Date() });
    }
    
    componentDidMount() {
        this.second = setInterval(this.tick, 1000)
    }

    componentWillUnmount() {
        clearInterval(this.second);
    }
    
    render(){
        return (
            <>
                <h1>Best Clock Ever</h1>
                    <section class="clock-widget">
                        <div class="clock-headers">
                            <p>date</p>
                            <p>time</p>
                        </div>
                        <div>
                            <p>{this.state.date.toDateString()}</p>
                            <p>{this.state.date.getHours()}:
                            {this.state.date.getMinutes()}:
                            {this.state.date.getSeconds()}</p>
                        </div>
                    </section>
            </>
        );
    }

}


export default Clock;